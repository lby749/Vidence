"""Single source of truth for the desktop product version."""
VERSION = '1.0.0-beta.1'
TITLE = f'Open QQ Dot v{VERSION}'
