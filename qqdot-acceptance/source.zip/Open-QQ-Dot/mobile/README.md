# Open QQ Dot 手机客户端 — 协作预览版

当前版本：原生「协作」页面可按好友创建协作群、添加已启用智能体、填写成员分工、派发持久化任务、查看顺序交接发言和状态。

使用方法：桌面「设备与通话」选择好友，勾选协作权限并生成一次性配对码；手机设置页配对后进入「协作」。旧的只读设备令牌不会自动升级。模型、思考强度与项目权限沿用该好友的桌面设置。

同一请求重试返回原任务；上一轮未结束时禁止重叠派发。新接口要求设备令牌、协作权限和好友范围；配对码哈希可跨桌面和服务进程读取，仅能消费一次。讨论完成不代表代码或文件已经通过客观验收。

本次已编译调试 APK，并通过真实配对 HTTP 接口完成 Gemini 与 ZCode 接力。没有连接真机或模拟器，因此手机安装、触控布局和真实网络链路仍未验证。正式发布需换正式签名。

Windows 构建若遇 Android 工具链拒绝中文路径，可复制手机源码到 ASCII 临时目录，复用已有 JDK、SDK 37 和 Gradle 缓存。无需重复下载。

以下为早期阶段的架构记录，其中「未实现」列表不能代表当前版本：

A native Kotlin/Jetpack Compose thin client. It does **not** bundle Python,
NapCat, a browser engine, TTS models, or health SDKs.

## Build

Prerequisites: JDK 17+ and Android SDK platform 37. `local.properties` must point
at the SDK; it is intentionally not committed.

```powershell
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-25.0.4.101-hotspot"
.\gradlew.bat --no-daemon assembleRelease
```

On this machine:

```text
SDK: D:/Projects/project2/phone_app/tools/sdk
release APK: app/build/outputs/apk/release/app-release.apk
size: 2,154,554 bytes (2.05 MiB)
signature: APK Signature Scheme v2, Android Debug certificate
package: com.openqqdot.mobile
minSdk 29 / targetSdk 36 / compileSdk 37
```

The release APK is signed with the debug key **for local preview only**. Replace
`signingConfig` with a real release keystore before publishing.

## What works

- Native Compose shell with Overview / Chat / Agent / Task / Settings
- Reads the desktop `vnext_bridge.py` over HTTP JSON:
  - `/api/overview`
  - `/api/friends`
  - `/api/agents`
  - `/api/tasks`
- Configurable bridge URL and optional Bearer token, saved in SharedPreferences
- No mock counts: if the bridge is unreachable the UI shows an explicit error
- R8 + resource shrinking enabled for release

## What is explicitly not implemented

- Device pairing / DeviceGateway / HTTPS/WSS
- Chat write and push notifications
- Streaming ASR/TTS and voice calls
- Health Connect and brand health adapters
- Agent creation/control
- Real phone-to-PC connection test: this machine has **no connected Android
  device or emulator** (`adb devices` is empty), so installation and runtime on
  a phone are **not verified**.

The default URL `http://10.0.2.2:8791` is for an Android emulator. A real phone
must use the PC's LAN address; cleartext HTTP is enabled only for this phase and
must be replaced by the authenticated DeviceGateway transport.
