# Keep JSON access through org.json only; Compose has its own consumer rules.
