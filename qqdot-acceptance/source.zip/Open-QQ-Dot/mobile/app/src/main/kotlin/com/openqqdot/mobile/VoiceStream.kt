package com.openqqdot.mobile

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * WSS utterance stream.  It intentionally streams one utterance at a time; the
 * protocol and server also stop at an explicit end frame.
 */
class VoiceStream(
    private val url: String,
    private val onReady: () -> Unit,
    private val onText: (String) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .apply {
            val config = TlsTrust.socketConfig(url)
            if (config != null) {
                sslSocketFactory(config.first, config.second)
                hostnameVerifier { _, _ -> true }
            }
        }
        .build()
    private var socket: WebSocket? = null
    private var opened = false

    fun connect() {
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                opened = true
                webSocket.send(JSONObject().put("type", "start").put("sample_rate", 16000).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val event = try { JSONObject(text) } catch (_: Exception) { return }
                when (event.optString("type")) {
                    "ready" -> onReady()
                    "final" -> onText(event.optString("text"))
                    "error" -> onError(event.optString("error", "语音流错误"))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                opened = false
                onError(t.message ?: "WSS 连接失败")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                opened = false
            }
        })
    }

    fun sendPcm(bytes: ByteArray) {
        if (opened) socket?.send(ByteString.of(*bytes))
    }

    fun end() {
        // Wait for the server's final frame; onText/onError closes the socket.
        if (opened) socket?.send(JSONObject().put("type", "end").toString())
    }

    fun close() {
        opened = false
        socket?.cancel()
        socket = null
    }
}
