package com.openqqdot.mobile

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

/** Required by Health Connect when the permission controller asks for a rationale. */
class PermissionsRationaleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "Open QQ Dot 只读取最近 24 小时的步数、睡眠和运动汇总，用于在你授权的桌面上显示健康状态。原始记录不会上传；你可以随时在 Health Connect 中撤销权限。"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(48, 96, 48, 48)
        }
        setContentView(LinearLayout(this).apply { addView(text) })
    }
}
