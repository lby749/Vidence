package com.openqqdot.mobile

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private enum class CallState(val label: String) {
    IDLE("空闲"),
    CONNECTING("连接中"),
    LISTENING("正在听"),
    THINKING("正在生成上下文回复"),
    SPEAKING("正在播放回复"),
    ENDED("已结束"),
    ERROR("错误"),
}

@Composable
fun CallScreen(base: String, token: String, qq: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recorder = remember { VoiceRecorder() }
    val audioManager = remember { context.getSystemService(AudioManager::class.java) }
    var state by remember { mutableStateOf(CallState.IDLE) }
    var muted by remember { mutableStateOf(false) }
    var transcript by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("点击开始通话，麦克风只在通话中启用。") }
    var startedAt by remember { mutableStateOf(0L) }
    var stream by remember { mutableStateOf<VoiceStream?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var active by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(audioManager.isSpeakerphoneOn) }
    val aecAvailable = remember { AcousticEchoCanceler.isAvailable() }
    var callQq by rememberSaveable { mutableStateOf(qq) }
    var invite by remember { mutableStateOf<JSONObject?>(null) }
    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    LaunchedEffect(token) {
        while (true) {
            try {
                val pending = Bridge.pendingInvites(base, token)
                invite = pending.firstOrNull()
            } catch (_: Exception) {}
            delay(3000)
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (!granted) { state = CallState.ERROR; status = "没有麦克风权限，无法通话" }
    }

    fun finish(reason: String) {
        active = false
        try { audioManager.mode = AudioManager.MODE_NORMAL } catch (_: Exception) {}
        recording = false
        recorder.stop()
        player?.stop(); player?.release(); player = null
        stream?.end()
        stream = null
        state = CallState.ENDED
        status = reason
    }

    fun start() {
        if (token.isBlank()) {
            state = CallState.ERROR; status = "请先在设置页完成设备配对"; return
        }
        if (!permissionGranted) { permission.launch(Manifest.permission.RECORD_AUDIO); return }
        active = true
        try { audioManager.mode = AudioManager.MODE_IN_COMMUNICATION } catch (_: Exception) {}
        state = CallState.CONNECTING
        transcript = ""
        status = "正在连接 WSS 语音通道…"
        startedAt = System.currentTimeMillis()
        val voice = VoiceStream(
            "wss://10.0.2.2:8793",
            onReady = {
                scope.launch(Dispatchers.Main) {
                    state = CallState.LISTENING
                    status = "已连接；说话结束后会自动送出这一轮语音。"
                    if (!recording) {
                        recording = recorder.start(onChunk = { chunk -> if (!muted) stream?.sendPcm(chunk) }, echoCancel = true)
                    }
                }
            },
            onText = { value ->
                scope.launch(Dispatchers.Main) {
                    transcript = value
                    state = CallState.THINKING
                    status = "正在把这句话交给同一位好友的上下文、记忆与人设生成回复…"
                    stream = null
                    if (callQq.isBlank()) { state = CallState.ERROR; status = "没有可用的好友 QQ"; return@launch }
                    try {
                        val (reply, wav) = withContext(Dispatchers.IO) { Bridge.call(base, token, callQq, value) }
                        transcript = reply
                        if (wav == null) {
                            state = CallState.ENDED
                            status = "已生成上下文回复，但 TTS 不可用：$reply"
                        } else {
                            val file = File(context.cacheDir, "qqdot_call_reply.wav")
                            file.writeBytes(wav)
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(file.absolutePath)
                                setOnCompletionListener {
                                    release()
                                    if (active) {
                                        status = "回复播放完，继续听你说…"
                                        start()
                                    } else {
                                        state = CallState.ENDED
                                        status = "通话已结束。"
                                    }
                                }
                                prepare(); start()
                            }
                            state = CallState.SPEAKING
                            status = "正在播放上下文回复…"
                        }
                    } catch (exc: Exception) {
                        state = CallState.ERROR
                        status = "生成回复失败：${exc.message ?: "unknown"}"
                    }
                }
            },
            onError = { message ->
                scope.launch(Dispatchers.Main) {
                    state = CallState.ERROR
                    status = "语音通道断开：$message"
                    recorder.stop()
                    stream = null
                }
            },
        )
        stream = voice
        voice.connect()
    }

    Column(
        Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("语音通话", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
        Text("语音对话：真实麦克风 → WSS → ASR → 该好友的聊天上下文/记忆/人设 → 桌面 TTS。仍不是完整双工电话。",
            fontSize = 10.sp, color = Color(0xFF64748B))
        if (transcript.isNotBlank()) {
            Text("最近一轮：$transcript", fontSize = 11.sp, color = Color(0xFF334155),
                modifier = Modifier.fillMaxWidth().background(Color(0xFFFFFFFF), RoundedCornerShape(10.dp)).padding(10.dp))
        }
        invite?.let { item ->
            Column(Modifier.fillMaxWidth().background(Color(0xFFEFF6FF), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(14.dp)).padding(14.dp)) {
                Text("来电邀请", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D4ED8))
                Text("好友 ${item.optString("qq")} 邀请你语音通话。接听后才会打开麦克风。", fontSize = 10.sp, color = Color(0xFF475569))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val id = item.optString("id")
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { Bridge.respondInvite(base, token, id, true) }
                                callQq = item.optString("qq", qq)
                                invite = null
                                start()
                            } catch (exc: Exception) { status = "接听失败：${exc.message}" }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))) { Text("接听") }
                    OutlinedButton(onClick = {
                        val id = item.optString("id")
                        scope.launch {
                            try { withContext(Dispatchers.IO) { Bridge.respondInvite(base, token, id, false) } } catch (_: Exception) {}
                            invite = null
                        }
                    }) { Text("拒绝") }
                }
            }
        }

        Column(
            Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFFDBEAFE), RoundedCornerShape(16.dp)).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(92.dp).background(
                if (state == CallState.LISTENING) Color(0xFFDCFCE7) else Color(0xFFEFF6FF), CircleShape),
                contentAlignment = Alignment.Center) {
                Text(state.label.take(2), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    color = if (state == CallState.LISTENING) Color(0xFF15803D) else Color(0xFF1D4ED8))
            }
            Spacer(Modifier.height(10.dp))
            Text(state.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A))
            if (startedAt > 0) {
                Text(if (state == CallState.ENDED) "通话已结束" else "通话中", fontSize = 10.sp, color = Color(0xFF64748B))
            }
            Spacer(Modifier.height(8.dp))
            Text(status, fontSize = 10.sp, color = Color(0xFF64748B))
            if (transcript.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("识别：$transcript", fontSize = 12.sp, color = Color(0xFF0F172A))
            }
            Spacer(Modifier.height(16.dp))
            when (state) {
                CallState.IDLE, CallState.ENDED, CallState.ERROR -> Button(
                    onClick = { startedAt = 0; start() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                ) { Text(if (state == CallState.ERROR) "重新拨打" else "开始通话") }
                CallState.CONNECTING -> Text("正在建立连接…", fontSize = 11.sp, color = Color(0xFF64748B))
                else -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { muted = !muted }) { Text(if (muted) "取消静音" else "静音") }
                    OutlinedButton(onClick = {
                        speaker = !speaker
                        try { audioManager.isSpeakerphoneOn = speaker } catch (_: Exception) {}
                    }) { Text(if (speaker) "听筒" else "扬声器") }
                    OutlinedButton(onClick = {
                        stream?.end(); recorder.stop(); stream = null; player?.stop(); player?.release(); player = null
                        if (active) { status = "已打断，继续听。"; start() }
                    }) { Text("打断") }
                    Button(onClick = { finish("已挂断，麦克风已释放") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))) { Text("挂断") }
                }
            }
        }

        Text("权限：${if (permissionGranted) "已授予麦克风" else "未授予"} · AEC：${if (aecAvailable) "可用" else "不可用"} · 音频不写入本地文件 · 结束后释放录音",
            fontSize = 9.sp, color = Color(0xFF94A3B8))
    }
}
