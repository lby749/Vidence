package com.openqqdot.mobile

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Minimal 16 kHz mono PCM recorder.  It writes a standard WAV so the desktop
 * ASR path can read it without FFmpeg or a second codec.
 */
class VoiceRecorder {
    private var record: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var thread: Thread? = null
    private val pcm = ByteArrayOutputStream()
    private val sampleRate = 16_000

    @SuppressLint("MissingPermission")
    fun start(echoCancel: Boolean = false, onChunk: ((ByteArray) -> Unit)? = null): Boolean {
        stopInternal()
        val minimum = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minimum <= 0) return false
        val bufferSize = maxOf(minimum, sampleRate / 2)
        val source = if (echoCancel) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
        val input = AudioRecord(
            source,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize,
        )
        if (input.state != AudioRecord.STATE_INITIALIZED) {
            input.release()
            return false
        }
        record = input
        if (echoCancel) {
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    echoCanceler = AcousticEchoCanceler.create(input.audioSessionId)
                    echoCanceler?.enabled = true
                }
            } catch (_: Exception) { echoCanceler = null }
        }
        pcm.reset()
        input.startRecording()
        thread = Thread {
            val buffer = ShortArray(bufferSize / 2)
            while (record === input) {
                val count = input.read(buffer, 0, buffer.size)
                if (count > 0) {
                    val bytes = ByteArray(count * 2)
                    ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buffer, 0, count)
                    synchronized(pcm) { pcm.write(bytes) }
                    onChunk?.invoke(bytes)
                }
            }
        }.also { it.start() }
        return true
    }

    fun stop(): ByteArray {
        val input = record ?: return ByteArray(0)
        record = null
        try { input.stop() } catch (_: Exception) {}
        try { thread?.join(700) } catch (_: InterruptedException) {}
        thread = null
        try { echoCanceler?.release() } catch (_: Exception) {}
        echoCanceler = null
        try { input.release() } catch (_: Exception) {}
        val data = synchronized(pcm) { pcm.toByteArray() }
        return wav(data)
    }

    private fun stopInternal() {
        record?.let {
            try { it.stop() } catch (_: Exception) {}
            try { echoCanceler?.release() } catch (_: Exception) {}
            echoCanceler = null
            try { it.release() } catch (_: Exception) {}
        }
        record = null
        thread = null
        pcm.reset()
    }

    private fun wav(pcmBytes: ByteArray): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcmBytes.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1)
        header.putShort(1)
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmBytes.size)
        return header.array() + pcmBytes
    }
}
