package com.openqqdot.mobile

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant

/**
 * Reads only the minimum Health Connect data.  The desktop never receives raw
 * records: this class reduces them to counts/durations, and the UI must still ask
 * the user to grant each Android health permission.
 */
object HealthConnectSource {
    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
    )

    fun client(context: Context): HealthConnectClient? =
        if (HealthConnectClient.getSdkStatus(context) == HealthConnectClient.SDK_AVAILABLE) {
            HealthConnectClient.getOrCreate(context)
        } else null

    fun statusLabel(context: Context): String = when (HealthConnectClient.getSdkStatus(context)) {
        HealthConnectClient.SDK_AVAILABLE -> "Health Connect 可用"
        HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> "需要更新 Health Connect"
        else -> "此设备不支持 Health Connect"
    }

    suspend fun granted(context: Context): Set<String> =
        client(context)?.permissionController?.getGrantedPermissions() ?: emptySet()

    suspend fun summary(context: Context): HealthSummary? {
        val client = client(context) ?: return null
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.containsAll(permissions)) return null
        val end = Instant.now()
        val start = end.minus(Duration.ofHours(24))
        val range = TimeRangeFilter.between(start, end)
        val steps = client.readRecords(ReadRecordsRequest(StepsRecord::class, timeRangeFilter = range))
            .records.sumOf { it.count }
        val sleep = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, timeRangeFilter = range))
            .records.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
        val workouts = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, timeRangeFilter = range))
            .records.size
        return HealthSummary(steps = steps, sleepMinutes = sleep, workouts = workouts,
            from = start.toString(), to = end.toString())
    }
}

data class HealthSummary(val steps: Long, val sleepMinutes: Long, val workouts: Int, val from: String, val to: String)
