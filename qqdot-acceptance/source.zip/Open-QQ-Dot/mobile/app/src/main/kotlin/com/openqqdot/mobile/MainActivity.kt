package com.openqqdot.mobile

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.util.Base64
import java.io.File
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private val Paper = Color(0xFFF6F3ED)
private val Card = Color(0xFFFFFEFB)
private val Sidebar = Color(0xFFEBE6DD)
private val Ink = Color(0xFF242320)
private val Muted = Color(0xFF79756D)
private val Line = Color(0xFFDED9D0)
private val Sage = Color(0xFF87988A)
private val SafeInk = Color(0xFF5A6659)

data class Overview(val friends: Int, val agents: Int, val tasks: Int, val mail: Int, val memories: Int, val root: String)
data class Friend(val qq: String, val name: String, val provider: String, val voice: String)
data class Agent(val backend: String, val name: String, val transport: String, val installed: Boolean?)
data class Task(val id: String, val title: String, val status: String)

sealed interface LoadState {
    data object Loading : LoadState
    data class Ready(val overview: Overview, val friends: List<Friend>, val agents: List<Agent>, val tasks: List<Task>) : LoadState
    data class Failed(val message: String) : LoadState
}

object TlsTrust {
    private var context: android.content.Context? = null
    fun init(appContext: android.content.Context) {
        context = appContext.applicationContext
    }
    private fun host(address: String): String = java.net.URI(address.trim()).host?.lowercase().orEmpty()
    fun savedPin(address: String): String = try {
        context?.getSharedPreferences("tls_pins", Context.MODE_PRIVATE)?.getString(host(address), "").orEmpty()
    } catch (_: Exception) { "" }
    fun savePin(address: String, fingerprint: String) {
        val server = host(address)
        require(server.isNotBlank()) { "请填写完整的桌面服务地址" }
        val value = fingerprint.replace(":", "").replace(" ", "").lowercase()
        require(value.isEmpty() || value.matches(Regex("[0-9a-f]{64}"))) { "证书指纹须为 64 位 SHA-256；请从桌面核对并复制" }
        context!!.getSharedPreferences("tls_pins", Context.MODE_PRIVATE).edit().putString(server, value).apply()
    }
    fun socketConfig(address: String): Pair<javax.net.ssl.SSLSocketFactory, javax.net.ssl.X509TrustManager>? {
        val pin = savedPin(address)
        if (pin.isBlank()) return null // Public-CA certificates use Android's normal trust and hostname validation.
        val manager = object : javax.net.ssl.X509TrustManager {
            override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) { throw java.security.cert.CertificateException("仅供服务端证书验证") }
            override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {
                if (chain.isEmpty()) throw java.security.cert.CertificateException("服务端未提供证书")
                chain[0].checkValidity()
                val actual = java.security.MessageDigest.getInstance("SHA-256").digest(chain[0].encoded).joinToString("") { "%02x".format(it) }
                if (actual != pin) throw java.security.cert.CertificateException("桌面证书指纹不匹配，已停止连接")
            }
        }
        val ssl = SSLContext.getInstance("TLS").apply { init(null, arrayOf(manager), null) }
        return ssl.socketFactory to manager
    }
    fun configure(connection: java.net.HttpURLConnection) {
        if (connection !is HttpsURLConnection) return
        val config = socketConfig(connection.url.toString()) ?: return
        connection.sslSocketFactory = config.first
        connection.hostnameVerifier = HostnameVerifier { _, _ -> true }
    }
}

object Bridge {
    fun get(base: String, token: String, path: String): String {
        val connection = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        TlsTrust.configure(connection)
        connection.connectTimeout = 4000
        connection.readTimeout = 5000
        connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/json")
        if (token.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
        if (token.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
        try {
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally {
            connection.disconnect()
        }
    }

    fun post(base: String, path: String, body: JSONObject, token: String = ""): JSONObject {
        val connection = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        TlsTrust.configure(connection)
        connection.connectTimeout = 4000
        connection.readTimeout = 30000
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")
        if (token.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
            if (connection.responseCode !in 200..299) error(JSONObject(text).optString("error", "HTTP ${connection.responseCode}"))
            return JSONObject(text)
        } finally { connection.disconnect() }
    }

    suspend fun pair(base: String, code: String, name: String): String = withContext(Dispatchers.IO) {
        post(base, "/api/device/pair", JSONObject().put("code", code).put("name", name)).getString("token")
    }

    suspend fun collaborate(base: String, token: String, owner: String, body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        post(base, "/api/collaboration", body.put("owner", owner), token)
    }

    suspend fun reportHealth(base: String, token: String, note: String): Unit = withContext(Dispatchers.IO) {
        post(base, "/api/health/report", JSONObject().put("adapter", "health_connect").put("supported", true).put("note", note), token)
        Unit
    }

    suspend fun transcribe(base: String, token: String, wav: ByteArray): String = withContext(Dispatchers.IO) {
        val encoded = Base64.encodeToString(wav, Base64.NO_WRAP)
        post(base, "/api/voice/transcribe", JSONObject().put("wav_base64", encoded), token).getString("text")
    }

    suspend fun refresh(base: String, token: String): String? = withContext(Dispatchers.IO) {
        try { post(base, "/api/device/refresh", JSONObject(), token).getString("token") } catch (_: Exception) { null }
    }

    suspend fun pendingInvites(base: String, token: String): List<org.json.JSONObject> = withContext(Dispatchers.IO) {
        val result = JSONObject(get(base, token, "/api/voice/invites"))
        val items = result.optJSONArray("items") ?: org.json.JSONArray()
        (0 until items.length()).map { items.getJSONObject(it) }
    }

    suspend fun respondInvite(base: String, token: String, id: String, accept: Boolean): Unit = withContext(Dispatchers.IO) {
        post(base, "/api/voice/invites/respond", JSONObject().put("id", id).put("accept", accept), token)
    }

    suspend fun call(base: String, token: String, qq: String, text: String): Pair<String, ByteArray?> = withContext(Dispatchers.IO) {
        val result = post(base, "/api/voice/call", JSONObject().put("qq", qq).put("text", text), token)
        val wav = result.optString("wav_base64", "")
        result.getString("reply") to if (wav.isBlank()) null else Base64.decode(wav, Base64.DEFAULT)
    }

    suspend fun synthesize(base: String, token: String, text: String): ByteArray = withContext(Dispatchers.IO) {
        val result = post(base, "/api/voice/synthesize", JSONObject().put("text", text).put("atmosphere", JSONObject().put("preset", "dry")), token)
        Base64.decode(result.getString("wav_base64"), Base64.DEFAULT)
    }

    suspend fun ingestHealth(base: String, token: String, summary: HealthSummary): Unit = withContext(Dispatchers.IO) {
        val now = java.time.OffsetDateTime.now().toString()
        post(base, "/api/health/events", JSONObject()
            .put("adapter", "health_connect").put("event_type", "steps_change").put("occurred_at", now)
            .put("scope", "steps").put("value", JSONObject().put("steps", summary.steps)), token)
        post(base, "/api/health/events", JSONObject()
            .put("adapter", "health_connect").put("event_type", "sleep_end").put("occurred_at", now)
            .put("scope", "sleep").put("value", JSONObject().put("minutes", summary.sleepMinutes)), token)
    }

    suspend fun load(base: String, token: String): LoadState = withContext(Dispatchers.IO) {
        try {
            val overview = JSONObject(get(base, token, "/api/overview"))
            val friendsJson = JSONArray(JSONObject(get(base, token, "/api/friends")).getJSONArray("items").toString())
            val agentsJson = JSONArray(JSONObject(get(base, token, "/api/agents")).getJSONArray("items").toString())
            val tasksJson = JSONArray(JSONObject(get(base, token, "/api/tasks")).getJSONArray("items").toString())
            val friends = (0 until friendsJson.length()).map {
                val o = friendsJson.getJSONObject(it)
                Friend(o.optString("qq"), o.optString("name"), o.optString("provider"), o.optString("voice"))
            }
            val agents = (0 until agentsJson.length()).map {
                val o = agentsJson.getJSONObject(it)
                Agent(o.optString("backend"), o.optString("display_name"), o.optString("transport"),
                    if (o.isNull("installed")) null else o.optBoolean("installed"))
            }
            val tasks = (0 until tasksJson.length()).map {
                val o = tasksJson.getJSONObject(it)
                Task(o.optString("id"), o.optString("title"), o.optString("status"))
            }
            LoadState.Ready(
                Overview(overview.optInt("friends"), overview.optInt("agents"), overview.optInt("tasks"),
                    overview.optInt("mail_messages"), overview.optInt("memories"), overview.optString("root")),
                friends, agents, tasks,
            )
        } catch (exc: Exception) {
            LoadState.Failed(exc.message ?: exc.javaClass.simpleName)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TlsTrust.init(applicationContext)
        setContent { OpenQQDotMobile() }
    }
}

@Composable
fun OpenQQDotMobile() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("bridge", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var base by rememberSaveable { mutableStateOf(prefs.getString("base", "http://10.0.2.2:8791") ?: "http://10.0.2.2:8791") }
    var token by rememberSaveable { mutableStateOf(prefs.getString("token", "") ?: "") }
    var page by rememberSaveable { mutableStateOf("概览") }
    var state by remember { mutableStateOf<LoadState>(LoadState.Loading) }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        if (token.isNotBlank()) {
            val fresh = Bridge.refresh(base, token)
            if (fresh != null) {
                token = fresh
                prefs.edit().putString("token", fresh).apply()
            }
        }
    }

    LaunchedEffect(base, token, reload) {
        state = LoadState.Loading
        var result = Bridge.load(base, token)
        repeat(2) {
            val failure = result as? LoadState.Failed ?: return@repeat
            if (!failure.message.contains("stream") && !failure.message.contains("connect") &&
                !failure.message.contains("refused")) return@repeat
            delay(800)
            result = Bridge.load(base, token)
        }
        state = result
    }

    MaterialTheme {
        Scaffold(
            containerColor = Paper,
            bottomBar = {
                NavigationBar(containerColor = Sidebar, tonalElevation = 0.dp) {
                    listOf("概览", "聊天", "协作", "通话", "任务", "设置").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Text(item.take(1), fontWeight = FontWeight.Bold) },
                            label = { Text(item, fontSize = 10.sp) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().background(Paper)) {
                Header(page, base, state)
                if (page == "设置") {
                    SettingsScreen(base, token, onSave = { newBase, newToken ->
                            base = newBase; token = newToken
                            prefs.edit().putString("base", newBase).putString("token", newToken).apply()
                            reload++
                        }, onPaired = { pairBase, code, name, report ->
                            scope.launch {
                                try {
                                    val newToken = Bridge.pair(pairBase, code, name)
                                    base = pairBase; token = newToken
                                    prefs.edit().putString("base", pairBase).putString("token", newToken).apply()
                                    reload++
                                    report("配对成功，已保存独立设备令牌")
                                } catch (exc: Exception) {
                                    report("配对失败：${exc.message ?: "未知错误"}")
                                }
                            }
                        })
                } else when (val current = state) {
                    is LoadState.Loading -> Loading()
                    is LoadState.Failed -> Offline(current.message, base) { reload++ }
                    is LoadState.Ready -> when (page) {
                        "概览" -> OverviewScreen(current)
                        "聊天" -> ChatScreen(current)
                        "协作" -> AgentScreen(current, base, token)
                        "通话" -> CallScreen(base, token, current.friends.firstOrNull()?.qq ?: "")
                        "任务" -> TaskScreen(current)
                        else -> Unit
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(page: String, base: String, state: LoadState) {
    Row(Modifier.fillMaxWidth().padding(18.dp, 16.dp, 18.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(page, fontSize = 25.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Text(if (state is LoadState.Ready) "已连接桌面服务 · 按设备权限操作" else "Open QQ Dot 手机端", fontSize = 10.sp, color = Muted)
        }
        Box(Modifier.background(if (state is LoadState.Ready) Color(0xFFEDF2EC) else Color(0xFFF7EFE6), RoundedCornerShape(99.dp)).padding(7.dp, 4.dp)) {
            Text(if (state is LoadState.Ready) "已连接" else "未连接", fontSize = 10.sp, color = if (state is LoadState.Ready) Color(0xFF526451) else Color(0xFF876B4D))
        }
    }
}

@Composable
private fun Loading() {
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(5) { Box(Modifier.fillMaxWidth().height(72.dp).background(Card, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp))) }
    }
}

@Composable
private fun Offline(message: String, base: String, retry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("无法连接 Python Core", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(message, fontSize = 11.sp, color = Muted)
        Spacer(Modifier.height(4.dp))
        Text(base, fontSize = 10.sp, color = Muted)
        Spacer(Modifier.height(16.dp))
        Button(onClick = retry, colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("重新检查") }
        Spacer(Modifier.height(20.dp))
        Text("手机只读取桌面 Python Core；未在手机内打包 Python、NapCat 或浏览器。", fontSize = 10.sp, color = Muted)
    }
}

@Composable
private fun OverviewScreen(state: LoadState.Ready) {
    LazyColumn(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(16.dp)).border(1.dp, Line, RoundedCornerShape(16.dp)).padding(17.dp)) {
                Text("今天，先看清楚正在发生什么。", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text("这是现有 Python Core 的只读快照。聊天写入、实时语音通话和健康接入尚未迁移。", fontSize = 11.sp, color = Muted)
                Spacer(Modifier.height(8.dp))
                Text(state.overview.root, fontSize = 9.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("好友", state.overview.friends, Modifier.weight(1f))
                Stat("Agent", state.overview.agents, Modifier.weight(1f))
                Stat("任务", state.overview.tasks, Modifier.weight(1f))
            }
        }
        item { SectionTitle("最近任务", "${state.tasks.size} 条") }
        items(state.tasks.take(5)) { task ->
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(task.title, fontSize = 11.sp, color = Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(task.id, fontSize = 8.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(task.status, fontSize = 8.sp, color = if (task.status == "COMPLETED") Sage else Color(0xFF876B4D))
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier = Modifier) {
    Column(modifier.background(Card, RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(label, fontSize = 9.sp, color = Muted)
        Text("$value", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Ink)
    }
}

@Composable
private fun SectionTitle(title: String, caption: String) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text(caption, fontSize = 9.sp, color = Muted)
    }
}

@Composable
private fun ChatScreen(state: LoadState.Ready) {
    LazyColumn(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("会话", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink) }
        items(state.friends) { friend ->
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).background(Sidebar, RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) { Text(friend.name.take(1), color = Ink) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(friend.name, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Ink)
                    Text("${friend.qq} · ${friend.provider}", fontSize = 9.sp, color = Muted)
                }
                Text("只读", fontSize = 9.sp, color = Muted)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 20.dp).background(Card, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(18.dp)) {
                Text("本页暂时只读，可在桌面聊天或使用手机通话页", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text("手机端不直接写 SQLite，也不把 Python/NapCat 打进 APK。发送与接收将通过已配对的桌面 Core。", fontSize = 10.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun AgentScreen(state: LoadState.Ready, base: String, token: String) {
    var owner by rememberSaveable { mutableStateOf("") }
    var authorized by remember(base, token) { mutableStateOf(emptyList<Friend>()) }
    var notice by remember(base, token) { mutableStateOf("正在读取设备的协作范围…") }
    LaunchedEffect(base, token) {
        try {
            val result = Bridge.collaborate(base, token, "", JSONObject().put("action", "owners")).getJSONArray("items")
            authorized = (0 until result.length()).map { i -> val item = result.getJSONObject(i)
                Friend(item.getString("qq"), item.getString("name"), item.optString("provider"), item.optString("voice")) }
            if (authorized.none { it.qq == owner }) owner = authorized.firstOrNull()?.qq.orEmpty()
            notice = if (authorized.isEmpty()) "设备没有已授权的好友，请在桌面选择好友并重新配对。" else ""
        } catch (exc: Exception) { notice = exc.message ?: "无法读取设备授权范围" }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("智能体协作", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text("选择好友 → 建协作群 → 添加成员与分工 → 派发任务。模型和权限沿用该好友的桌面设置。", fontSize = 11.sp, color = Muted)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            authorized.forEach { friend ->
                FilterChip(selected = owner == friend.qq, onClick = { owner = friend.qq }, label = { Text(friend.name) })
            }
        }
        if (notice.isNotBlank()) Text(notice, color = Muted, fontSize = 11.sp)
        if (authorized.any { it.qq == owner }) key(base, token, owner) { CollaborationRoomPanel(base, token, owner) }
    }
}

@Composable
private fun CollaborationRoomPanel(base: String, token: String, owner: String) {
    val scope = rememberCoroutineScope()
    var rooms by remember { mutableStateOf(emptyList<JSONObject>()) }
    var providers by remember { mutableStateOf(emptyList<String>()) }
    var roomId by remember { mutableStateOf("") }
    var room by remember { mutableStateOf<JSONObject?>(null) }
    var task by remember { mutableStateOf<JSONObject?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var provider by remember { mutableStateOf("") }
    var memberName by rememberSaveable { mutableStateOf("") }
    var role by rememberSaveable { mutableStateOf("执行分到的任务，给出可核查的结果") }
    var input by rememberSaveable { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val requestId = remember(roomId, input) { java.util.UUID.randomUUID().toString() }
    fun objects(array: JSONArray?): List<JSONObject> = if (array == null) emptyList() else (0 until array.length()).map { array.getJSONObject(it) }
    fun runAction(body: JSONObject, after: (JSONObject) -> Unit = {}) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val result = Bridge.collaborate(base, token, owner, body)
                after(result)
                val listing = Bridge.collaborate(base, token, owner, JSONObject().put("action", "list"))
                rooms = objects(listing.optJSONArray("rooms"))
                if (roomId.isNotBlank()) {
                    val current = Bridge.collaborate(base, token, owner, JSONObject().put("action", "get").put("room_id", roomId))
                    room = current.getJSONObject("room")
                    task = current.optJSONObject("task")
                }
                status = "已保存，执行进度会自动刷新"
            } catch (exc: Exception) { status = exc.message ?: "请求未确认，请刷新检查后再试" }
            finally { busy = false }
        }
    }
    LaunchedEffect(base, token, owner) {
        try {
            val result = Bridge.collaborate(base, token, owner, JSONObject().put("action", "list"))
            rooms = objects(result.optJSONArray("rooms"))
            val choices = result.optJSONArray("providers") ?: JSONArray()
            providers = (0 until choices.length()).map { choices.getString(it) }
            provider = providers.firstOrNull().orEmpty()
            roomId = rooms.firstOrNull()?.optString("id").orEmpty()
        } catch (exc: Exception) { status = exc.message ?: "无法读取协作群" }
    }
    LaunchedEffect(roomId) {
        room = null; task = null
        if (roomId.isNotBlank()) {
            while (true) {
                try {
                    val result = Bridge.collaborate(base, token, owner, JSONObject().put("action", "get").put("room_id", roomId))
                    room = result.getJSONObject("room")
                    task = result.optJSONObject("task")
                } catch (exc: kotlinx.coroutines.CancellationException) { throw exc }
                catch (exc: Exception) { status = exc.message ?: "进度刷新失败" }
                delay(4000)
            }
        }
    }
    val states = mapOf("PENDING" to "等待执行", "RUNNING" to "成员正在协作", "VERIFYING" to "核对结果结构",
        "COMPLETED" to "本轮发言已完成", "FAILED" to "本轮失败", "PAUSED" to "已暂停，请在桌面处理",
        "WAITING_RESOURCE" to "等待额度或资源", "WAITING_APPROVAL" to "等待确认", "CANCELLED" to "已终止")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            OutlinedTextField(title, { title = it }, label = { Text("新协作群名称") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { runAction(JSONObject().put("action", "create").put("title", title)) { roomId = it.getJSONObject("room").getString("id"); title = "" } },
                enabled = !busy && title.isNotBlank()) { Text("创建协作群") }
            Text(status, color = Muted, fontSize = 11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rooms.forEach { item -> FilterChip(selected = roomId == item.optString("id"), onClick = { roomId = item.optString("id") }, label = { Text(item.optString("title")) }) }
            }
        }
        if (roomId.isNotBlank()) {
            item {
                Text("成员与分工", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("仅列出当前好友启用的智能体。模型和思考强度在桌面统一配置。", fontSize = 10.sp, color = Muted)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    providers.forEach { choice -> FilterChip(selected = provider == choice, onClick = { provider = choice }, label = { Text(choice) }) }
                }
                OutlinedTextField(memberName, { memberName = it }, label = { Text("成员名称（例如：执行者）") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(role, { role = it }, label = { Text("这个成员负责什么") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { runAction(JSONObject().put("action", "add").put("room_id", roomId).put("provider", provider).put("name", memberName).put("role", role)) { memberName = "" } },
                    enabled = !busy && provider.isNotBlank() && role.isNotBlank()) { Text("添加成员") }
            }
            items(objects(room?.optJSONArray("members")), key = { it.getString("id") }) { member ->
                Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text(member.optString("name") + " · " + member.optString("provider"), color = Ink, fontWeight = FontWeight.Medium)
                    Text(member.optString("role"), fontSize = 11.sp, color = Muted)
                    TextButton(onClick = { runAction(JSONObject().put("action", "remove").put("room_id", roomId).put("member_id", member.getString("id"))) }, enabled = !busy) { Text("移除此成员") }
                }
            }
            item {
                OutlinedTextField(input, { input = it }, label = { Text("给这个协作群的任务") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Button(onClick = { runAction(JSONObject().put("action", "run").put("room_id", roomId).put("text", input).put("request_id", requestId)) { status = "已进入持久化任务队列"; input = "" } },
                    enabled = !busy && input.isNotBlank() && objects(room?.optJSONArray("members")).isNotEmpty()) { Text(if (busy) "正在提交…" else "派发任务（使用模型额度）") }
                task?.let { item ->
                    Text(states[item.optString("status")] ?: "请查看桌面任务状态", color = Ink, fontWeight = FontWeight.SemiBold)
                    if (item.optString("error").isNotBlank()) Text(item.optString("error"), color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }
                Text("成员按顺序交接，发言与任务状态保存于当前好友。讨论完成不等于代码或文件已通过实际验收。", color = Muted, fontSize = 10.sp)
            }
            items(objects(room?.optJSONArray("messages")), key = { it.getString("id") }) { message ->
                Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text(message.optString("name"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Sage)
                    Text(message.optString("content"), fontSize = 12.sp, color = Ink)
                }
            }
        }
    }
}

@Composable
private fun TaskScreen(state: LoadState.Ready) {
    LazyColumn(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item { Text("任务快照", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink) }
        items(state.tasks) { task ->
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)).padding(11.dp)) {
                Text(task.title, fontSize = 11.sp, color = Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${task.id} · ${task.status}", fontSize = 8.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun VoiceCard(base: String, token: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recorder = remember { VoiceRecorder() }
    var text by rememberSaveable { mutableStateOf("你好，这是手机语音合成测试。") }
    var status by remember { mutableStateOf("") }
    var transcript by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var streaming by remember { mutableStateOf(false) }
    var streamUrl by rememberSaveable { mutableStateOf("wss://10.0.2.2:8793") }
    var activeStream by remember { mutableStateOf<VoiceStream?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted && recorder.start()) { recording = true; status = "正在录音…再次点击结束并识别" }
        else if (!granted) status = "没有麦克风权限"
    }
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text("手机语音", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text("调用桌面 TTS/ASR；录音只上传 WAV，不把模型打进 APK。", fontSize = 10.sp, color = Muted)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(text, { text = it }, label = { Text("要合成的文字") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (token.isBlank()) { status = "请先在设置页完成设备配对"; return@Button }
                busy = true; status = "正在合成…"
                scope.launch {
                    try {
                        val audio = Bridge.synthesize(base, token, text)
                        val file = File(context.cacheDir, "qqdot_voice.wav")
                        file.writeBytes(audio)
                        player?.release()
                        player = MediaPlayer().apply {
                            setDataSource(file.absolutePath)
                            setOnCompletionListener { release() }
                            prepare(); start()
                        }
                        status = "已播放 ${audio.size} 字节的桌面合成语音"
                    } catch (exc: Exception) { status = "合成失败：${exc.message ?: "unknown"}" }
                    finally { busy = false }
                }
            }, enabled = !busy && !recording, colors = ButtonDefaults.buttonColors(containerColor = SafeInk)) { Text(if (busy) "处理中…" else "合成并播放") }
            Button(onClick = {
                if (!recording) {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        player?.stop(); player?.release(); player = null
                        if (recorder.start()) { recording = true; status = "正在录音…再次点击结束并识别" }
                        else status = "无法启动麦克风"
                    } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else {
                    val wav = recorder.stop()
                    recording = false
                    if (wav.size < 1000) { status = "录音太短"; return@Button }
                    if (token.isBlank()) { status = "已录音；请先完成设备配对再上传"; return@Button }
                    busy = true; status = "正在上传识别…"
                    scope.launch {
                        try {
                            transcript = Bridge.transcribe(base, token, wav)
                            status = "已上传 ${wav.size} 字节 WAV"
                        } catch (exc: Exception) { status = "识别失败：${exc.message ?: "unknown"}" }
                        finally { busy = false }
                    }
                }
            }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFFB47A6B) else Color(0xFF5A6659))) {
                Text(if (recording) "停止并识别" else "录音识别")
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(streamUrl, { streamUrl = it }, label = { Text("WSS 语音流地址") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Button(onClick = {
            if (streaming) {
                recorder.stop()
                activeStream?.end()
                activeStream = null
                streaming = false
                status = "已结束流式录音"
                return@Button
            }
            if (token.isBlank()) { status = "请先完成设备配对"; return@Button }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO); return@Button
            }
            val stream = VoiceStream(streamUrl.trim(),
                onReady = { scope.launch(Dispatchers.Main) { status = "WSS 已连接，正在流式识别…" } },
                onText = { value -> scope.launch(Dispatchers.Main) { transcript = value; status = "WSS 识别完成"; streaming = false; activeStream = null } },
                onError = { message -> scope.launch(Dispatchers.Main) { if (streaming) { status = "WSS 失败：$message"; streaming = false; activeStream = null } } })
            activeStream = stream
            player?.stop(); player?.release(); player = null
            val startedAt = System.currentTimeMillis()
            var speechStarted = false
            var silenceSince = 0L
            var vadDone = false
            if (recorder.start { chunk ->
                stream.sendPcm(chunk)
                var sum = 0.0
                var i = 0
                while (i + 1 < chunk.size) {
                    val sample = ((chunk[i].toInt() and 0xFF) or (chunk[i + 1].toInt() shl 8)).toShort().toInt()
                    sum += sample.toDouble() * sample
                    i += 2
                }
                val rms = kotlin.math.sqrt(sum / (chunk.size / 2).coerceAtLeast(1))
                val now = System.currentTimeMillis()
                if (rms > 700) {
                    speechStarted = true
                    silenceSince = 0
                } else if (speechStarted && silenceSince == 0L) {
                    silenceSince = now
                }
                val silenceFor = if (silenceSince == 0L) 0 else now - silenceSince
                if (!vadDone && ((speechStarted && silenceFor > 1200) || (!speechStarted && now - startedAt > 4000))) {
                    vadDone = true
                    stream.end()
                    scope.launch(Dispatchers.Main) {
                        status = if (speechStarted) "检测到静音，正在识别…" else "未检测到人声，已结束"
                        recorder.stop()
                        streaming = false
                    }
                }
            }) {
                stream.connect(); streaming = true; status = "正在连接 WSS…"
            } else status = "无法启动麦克风"
        }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = if (streaming) Color(0xFFB47A6B) else Color(0xFF87988A))) {
            Text(if (streaming) "停止流式识别" else "WSS 流式识别")
        }
        if (status.isNotBlank()) Text(status, fontSize = 10.sp, color = Muted, modifier = Modifier.padding(top = 6.dp))
        if (transcript.isNotBlank()) Text("识别：$transcript", fontSize = 11.sp, color = Ink, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun HealthCard(base: String, token: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var summary by remember { mutableStateOf<HealthSummary?>(null) }
    var message by remember { mutableStateOf(HealthConnectSource.statusLabel(context)) }
    val launcher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        scope.launch {
            if (granted.containsAll(HealthConnectSource.permissions)) {
                val value = HealthConnectSource.summary(context)
                summary = value
                if (value == null) message = "权限已授予，但读取失败"
                else if (token.isBlank()) message = "已读取摘要；请先完成设备配对再上报"
                else {
                    try {
                        Bridge.reportHealth(base, token, "Android Health Connect")
                        Bridge.ingestHealth(base, token, value)
                        message = "已读取并上报汇总（仍需桌面授权对应 scope）"
                    } catch (exc: Exception) {
                        message = "已读取摘要，上报失败：${exc.message ?: "unknown"}"
                    }
                }
            } else message = "Health Connect 权限未全部授予"
        }
    }
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text("Health Connect", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text(message, fontSize = 10.sp, color = Muted)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { launcher.launch(HealthConnectSource.permissions) }, colors = ButtonDefaults.buttonColors(containerColor = SafeInk)) { Text("授权并读取最近 24 小时") }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = {
            try {
                context.startActivity(android.content.Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                message = "此设备没有 Health Connect 设置页"
            }
        }) { Text("打开 Health Connect 设置") }
        summary?.let { value ->
            Spacer(Modifier.height(8.dp))
            Text("步数：${value.steps} · 睡眠：${value.sleepMinutes} 分钟 · 运动：${value.workouts} 次", fontSize = 11.sp, color = Ink)
            Text("仅汇总，不上传原始记录；桌面只有在收到事件后才显示健康数据。", fontSize = 9.sp, color = Muted)
        }
    }
}

@Composable
private fun SettingsScreen(base: String, token: String, onSave: (String, String) -> Unit,
                           onPaired: (String, String, String, (String) -> Unit) -> Unit) {
    var url by rememberSaveable(base) { mutableStateOf(base) }
    var secret by rememberSaveable(token) { mutableStateOf(token) }
    var pairCode by rememberSaveable { mutableStateOf("") }
    var pairName by rememberSaveable { mutableStateOf("我的安卓手机") }
    var fingerprint by rememberSaveable(base) { mutableStateOf(TlsTrust.savedPin(base)) }
    var pairMessage by remember { mutableStateOf("") }
    Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("设备连接", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        OutlinedTextField(url, { url = it; secret = ""; fingerprint = TlsTrust.savedPin(it) }, label = { Text("桌面服务地址") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(fingerprint, { fingerprint = it }, label = { Text("本机证书 SHA-256 指纹（自签名 HTTPS 必填）") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(secret, { secret = it }, label = { Text("访问令牌（可选）") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { try { TlsTrust.savePin(url, fingerprint); onSave(url.trim(), secret.trim()) }
            catch (exc: Exception) { pairMessage = exc.message ?: "保存失败" } }, colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("保存并重新连接") }
        Spacer(Modifier.height(10.dp))
        Text("设备配对", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(pairCode, { pairCode = it.uppercase() }, label = { Text("配对码") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(pairName, { pairName = it }, label = { Text("设备名称") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Button(onClick = { try { TlsTrust.savePin(url, fingerprint); onPaired(url.trim(), pairCode.trim(), pairName.trim()) { message -> pairMessage = message } }
            catch (exc: Exception) { pairMessage = exc.message ?: "配对失败" } },
            colors = ButtonDefaults.buttonColors(containerColor = SafeInk)) { Text("用配对码连接") }
        if (pairMessage.isNotBlank()) Text(pairMessage, fontSize = 10.sp, color = if (pairMessage.startsWith("配对失败")) Color(0xFFB91C1C) else Color(0xFF15803D))
        Text("在桌面「设备与通话」生成配对码。使用本机自签名 HTTPS 时，从该页复制证书指纹并核对后填写；不再固定信任开发者电脑的证书。更换地址会清空旧令牌，防止发给另一台服务器。", fontSize = 10.sp, color = Muted)
        Text("默认 10.0.2.2 仅适用于 Android 模拟器；真机需使用可达的桌面服务地址。设备令牌与证书指纹仅保存在本机。", fontSize = 10.sp, color = Muted)
        Spacer(Modifier.height(18.dp))
        HealthCard(base, token)
        Spacer(Modifier.height(12.dp))
        VoiceCard(base, token)
        Spacer(Modifier.height(18.dp))
        Text("明确未接入", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text("真机网络、触控布局、系统通知与硬件通话仍需实机验收。手机协作通过受限设备接口调用桌面持久化任务。", fontSize = 10.sp, color = Muted)
    }
}
