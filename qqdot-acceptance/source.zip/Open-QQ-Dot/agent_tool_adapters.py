"""Explicitly approved external *agent* execution adapters for Open QQ Dot.

An agent is NOT an API model. This module does not automatically authorize CLI
processes, third-party sessions or their tool calls. TaskManager must enforce
owner, workspace, budget and verification before/after calling ``run_agent``.

Supported: OpenCode local HTTP, Cursor headless CLI, Qwen Code headless CLI,
ZCode headless CLI, Kimi Code/other ACP stdio, and MCP stdio tool discovery and invocation.
No dependency on the provider's Python SDK; native executables must be installed
and logged in separately. No untrusted command line or remote URL overrides.
"""
from __future__ import annotations

import base64
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote, urlsplit
from urllib.request import Request, build_opener, ProxyHandler


class AgentAdapterError(RuntimeError):
    pass


@dataclass(frozen=True)
class AgentAdapterSpec:
    name: str
    transport: str
    executable: str = ''
    args: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ('code', 'file', 'conversation')
    session_support: bool = False


BUILTINS = {
    'opencode': AgentAdapterSpec('OpenCode', 'http', 'opencode', session_support=True),
    'cursor': AgentAdapterSpec('Cursor Agent CLI', 'headless', 'agent'),
    'qwen_code': AgentAdapterSpec('千问', 'headless', 'qwen', session_support=True),
    'zcode': AgentAdapterSpec('ZCode CLI', 'headless', 'zcode', session_support=True),
    'kimi_code': AgentAdapterSpec('Kimi Code ACP', 'acp', 'kimi', ('acp',), session_support=True),
    'acp': AgentAdapterSpec('自定义智能体（ACP）', 'acp', session_support=True),
    'mcp': AgentAdapterSpec('工具服务（MCP）', 'mcp', capabilities=('tool_discovery', 'tool_call')),
}
BACKEND_NAMES = frozenset(BUILTINS)
AGENT_BACKENDS = tuple(key for key in BUILTINS if key != 'mcp')


def available_adapters() -> list[dict]:
    """Installation availability only. Installed ≠ authenticated ≠ operational."""
    from agent_backends.zcode_backend import cli_command
    return [{'backend': key, 'display_name': spec.name, 'transport': spec.transport,
             'installed': bool(_opencode_cli()) if key == 'opencode' else
                          bool(cli_command()) if key == 'zcode' else
                          bool(shutil.which(spec.executable)) if spec.executable else None,
             'session_support': spec.session_support, 'capabilities': list(spec.capabilities)}
            for key, spec in BUILTINS.items()]


def _workspace(path: str | Path) -> Path:
    p = Path(path).resolve(strict=True)
    if not p.is_dir():
        raise AgentAdapterError('Agent workspace must be an existing directory')
    return p


def _validate_program(program: str) -> str:
    """Never use shell=True; explicit trusted command only, no user prompts as executables."""
    if not isinstance(program, str) or not program or any(c in program for c in '\n\r\0'):
        raise AgentAdapterError('Invalid executable')
    found = shutil.which(program)
    if not found:
        raise AgentAdapterError('Agent executable is not installed or not on PATH')
    return found


def _parse_output(stdout: str, backend: str) -> tuple[str, str, int]:
    """Extract actual provider result, fail closed on error envelopes."""
    raw = stdout.strip()
    if not raw:
        raise AgentAdapterError(f'{backend} exited without a result')
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        # Some CLIs emit plain text in older versions. Do not mistake a crash for success.
        if raw.startswith('{') or raw.startswith('['):
            raise AgentAdapterError('Invalid JSON result from agent') from None
        return raw, '', 0
    if isinstance(obj, list):
        errors = [e for e in obj if isinstance(e, dict) and e.get('type') == 'result' and e.get('is_error')]
        if errors:
            raise AgentAdapterError('Qwen Code returned an error result')
        results = [e for e in obj if isinstance(e, dict) and e.get('type') == 'result']
        if not results:
            raise AgentAdapterError('Agent returned no final result event')
        obj = results[-1]
    if not isinstance(obj, dict) or obj.get('is_error') is True or obj.get('subtype') in ('error', 'failure'):
        raise AgentAdapterError('Agent returned an error envelope')
    text = obj.get('response') or obj.get('result') or obj.get('text') or obj.get('output')
    if not isinstance(text, str) or not text.strip():
        raise AgentAdapterError('Agent returned no final text')
    usage = obj.get('usage') or {}
    tokens = 0
    if isinstance(usage, dict):
        for key in ('total_tokens', 'totalTokens'):
            if type(usage.get(key)) is int:
                tokens = usage[key]
                break
        if not tokens:
            tokens = sum(usage.get(k, 0) for k in ('input_tokens', 'output_tokens') if type(usage.get(k)) is int)
    return text, str(obj.get('session_id') or obj.get('sessionId') or ''), tokens


def run_headless(backend: str, instruction: str, workspace: str | Path, *,
                 timeout: float = 600, allow_write: bool = False, command: list[str] | None = None,
                 env: dict | None = None) -> dict:
    """Official non-interactive CLI, bounded execution, no shell, no YOLO defaults."""
    if backend not in ('cursor', 'qwen_code', 'zcode'):
        raise AgentAdapterError('Unsupported headless backend')
    if not isinstance(instruction, str) or not instruction.strip() or len(instruction) > 50000:
        raise AgentAdapterError('Invalid instruction')
    cwd = _workspace(workspace)
    if not 1 <= timeout <= 3600:
        raise AgentAdapterError('Invalid execution timeout')
    try:
        program = _validate_program(command[0] if command else BUILTINS[backend].executable)
    except AgentAdapterError:
        if backend != 'cursor' or command:
            raise
        program = _validate_program('cursor-agent')
    if backend == 'cursor':
        # Cursor -p accepts the prompt as argv, and --force explicitly allows edits.
        # Never use --force unless TaskManager authorized code writes.
        argv = [program, *(command[1:] if command else []), '-p', instruction, '--output-format', 'json']
        if allow_write:
            argv.append('--force')
        data = None
    elif backend == 'zcode':
        # ZCode's official non-interactive mode.  It has no read-only switch:
        # plan only plans; yolo may execute tools and write files, so it is only
        # selected after TaskManager's explicit write authorization.
        argv = [program, *(command[1:] if command else []),
                '--prompt', instruction, '--cwd', str(cwd),
                '--mode', 'yolo' if allow_write else 'plan',
                '--json', '--no-color']
        data = None
    else:
        # Qwen supports prompt via stdin; avoids exposing prompts in process argv.
        argv = [program, *(command[1:] if command else []), '--output-format', 'json']
        data = instruction
    try:
        from task_runtime import run_process
        run = run_process(argv, input=data, cwd=str(cwd), capture_output=True, text=True,
                             encoding='utf-8', errors='replace', timeout=timeout, check=False, env=env)
    except subprocess.TimeoutExpired as exc:
        raise InterruptedError(f'{backend} 调用超时，执行结果尚未确认；请核对产物，不自动重复提交。') from exc
    if run.returncode != 0:
        # stderr can contain secrets or the original prompt; do not forward it to QQ/logs.
        raise AgentAdapterError(f'{backend} exited with code {run.returncode}; inspect provider logs locally')
    output, session, tokens = _parse_output(run.stdout, backend)
    return {'output': output, 'session_id': session, 'tokens_used': tokens,
            'backend': backend, 'verified': False, 'transport': 'headless'}


OPENCODE_DEFAULT_URL = 'http://127.0.0.1:4096'


def _loopback_url(url: str) -> str:
    """Accept only http://127.0.0.1:<port>, without credentials, path, query or fragment."""
    p = urlsplit(url.rstrip('/'))
    if (p.scheme != 'http' or p.hostname != '127.0.0.1' or p.username or p.password or
            p.path or p.query or p.fragment or not p.port or not (1 <= p.port <= 65535)):
        raise AgentAdapterError('OpenCode server must use http://127.0.0.1:<port>')
    return url.rstrip('/')


def _opencode_cli() -> str:
    """The installed OpenCode CLI: on PATH, or bundled with the desktop app."""
    found = shutil.which('opencode')
    if found:
        return found
    local = Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / '@opencodedesktop' / 'resources'
    candidates = [local / 'opencode-cli.exe']
    candidates += sorted((Path(os.environ.get('APPDATA', '')) / 'ai.opencode.desktop' / 'cli').glob(
        '*/opencode-cli.exe'), reverse=True)
    return next((str(path) for path in candidates if path.is_file()), '')


def opencode_discovery() -> tuple[str, str]:
    """(url, password) of the locally running OpenCode server; either may be ''.

    2026-10-26 user: "open code 接入失败". The installed desktop build (2.0.32) serves the v2 API on a port
    it picks at random and guards it with Basic auth, so the documented `serve` on 4096 never answered. The
    live URL comes from `opencode service status` and the password from the service config; an explicit
    loopback URL and OPENCODE_SERVER_PASSWORD still win.
    """
    url = ''
    cli = _opencode_cli()
    if cli:
        try:
            done = subprocess.run([cli, 'service', 'status'], capture_output=True, text=True, timeout=6,
                                  creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            lines = [line.strip() for line in (done.stdout or '').splitlines() if line.strip()]
            url = next((line for line in reversed(lines) if line.startswith('http://')), '')
        except (OSError, subprocess.SubprocessError):
            url = ''
    password = os.environ.get('OPENCODE_SERVER_PASSWORD', '')
    if not password:
        try:
            config = json.loads((Path.home() / '.config' / 'opencode' / 'service.json').read_text('utf-8'))
            password = str(config.get('password') or '')
        except (OSError, ValueError, TypeError):
            password = ''
    return url, password


def _message_text(message: dict) -> str:
    """Assistant text from a v2 message: either a flat `text` or typed content parts."""
    if isinstance(message.get('text'), str) and message['text'].strip():
        return message['text']
    parts = message.get('content') or message.get('parts') or []
    texts = [part['text'] for part in parts if isinstance(part, dict) and part.get('type') == 'text'
             and isinstance(part.get('text'), str) and part['text'].strip()]
    return '\n'.join(texts)


def _opencode_model(value) -> tuple[str, str] | tuple[()]:
    """'provider/model' from the trusted config; empty means the server's own default."""
    if not value:
        return ()
    text = str(value).strip()
    provider, _, name = text.partition('/')
    if (not name or not re.fullmatch(r'[A-Za-z0-9_.-]{1,64}', provider) or
            not re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}', name)):
        raise AgentAdapterError('OpenCode model must be provider/model, e.g. opencode/gemini-4-argon')
    return provider, name


def _opencode_variant(value) -> str:
    """Reasoning variant (thinking effort) reported by the model list; empty means the server default."""
    text = str(value or '').strip()
    if text and not re.fullmatch(r'[A-Za-z0-9_.-]{1,32}', text):
        raise AgentAdapterError('OpenCode 思考档位名称不合法')
    return text


def _opencode_error(error) -> str:
    """A readable reason first, then the provider's own words (2026-10-26: three different walls)."""
    if isinstance(error, dict):
        text = str(error.get('message') or error.get('type') or '未知错误')
    elif isinstance(error, str):
        text = error
    else:
        text = '未知错误'
    lowered = text.lower()
    if 'trains on request data' in lowered:
        hint = 'OpenCode 这个模型要求在 Privacy 设置里允许「会用请求数据训练的付费端点」，或换一个模型。'
    elif 'free usage limit' in lowered:
        hint = 'OpenCode 免费额度已用尽：需要订阅 OpenCode Go，或选一个已付费的模型。'
    elif 'insufficient account funds' in lowered:
        hint = 'OpenCode 账户余额不足：请充值或换一个可用模型。'
    else:
        hint = ''
    return (hint + ' 原始信息：' + text[:240]) if hint else text[:300]


class LocalOpenCode:
    """A loopback OpenCode server: v2 `/api/*` first, the v1 web API as a fallback.

    Never connects to a remote URL. A server started by hand is addressed by an explicit url and
    OPENCODE_SERVER_PASSWORD; the desktop build's background service is discovered automatically.
    """
    POLL_SECONDS = 1.5
    def __init__(self, url: str = '', *, username: str = 'opencode', password: str = '',
                 model: str = '', variant: str = ''):
        self.url = _loopback_url(url) if url else ''
        self.username = username
        self._password = password
        self.model = _opencode_model(model)
        self.variant = _opencode_variant(variant)
        self._base = ''
        self._resolved_password = ''
        self.api = 0

    # ---------- transport ----------
    def base_url(self) -> str:
        if not self._base:
            url, password = self.url, self._password
            if not url or not password:
                found_url, found_password = opencode_discovery()
                url = url or found_url
                password = password or found_password
            self._base = _loopback_url(url or OPENCODE_DEFAULT_URL)
            self._resolved_password = password
        return self._base

    def _call(self, path: str, data: dict | None = None, *, timeout: float = 30) -> object:
        base = self.base_url()  # resolves the port and password once
        headers = {'Accept': 'application/json'}
        if self._resolved_password:
            credentials = base64.b64encode(
                f'{self.username}:{self._resolved_password}'.encode()).decode()
            headers['Authorization'] = 'Basic ' + credentials
        payload = json.dumps(data, ensure_ascii=False).encode('utf-8') if data is not None else None
        if payload is not None:
            headers['Content-Type'] = 'application/json'
        # Disable HTTP redirects: redirects could carry Basic credentials elsewhere.
        from urllib.request import HTTPRedirectHandler
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        opener = build_opener(ProxyHandler({}), NoRedirect())
        req = Request(base + path, data=payload, headers=headers,
                      method='POST' if payload is not None else 'GET')
        try:
            with opener.open(req, timeout=timeout) as response:
                if response.status not in (200, 201):
                    raise AgentAdapterError(f'OpenCode returned HTTP {response.status}')
                return json.loads(response.read(4_000_000))
        except (OSError, ValueError) as exc:
            raise AgentAdapterError(f'OpenCode request failed: {type(exc).__name__}') from exc

    def info(self) -> dict:
        """Identify the server: v2 answers /api/info with a version, v1 answers /global/health."""
        try:
            obj = self._call('/api/info', timeout=5)
        except AgentAdapterError:
            obj = None
        if isinstance(obj, dict) and obj.get('version'):
            self.api = 2
            return obj
        obj = self._call('/global/health', timeout=5)
        if not isinstance(obj, dict) or not obj.get('healthy'):
            raise AgentAdapterError('OpenCode server not healthy')
        self.api = 1
        return obj

    health = info  # older callers and the desktop probe used this name

    def server_workspace(self) -> str:
        if not self.api:
            self.info()
        obj = self._call('/api/location' if self.api == 2 else '/path', timeout=5)
        value = obj.get('directory') if isinstance(obj, dict) else None
        if not isinstance(value, str) or not value:
            raise AgentAdapterError('Cannot verify OpenCode server workspace')
        return value

    def list_models(self) -> list[dict]:
        """Models this account can use, each with its reasoning variants (the 'thinking effort' tiers)."""
        self.info()
        if self.api != 2:
            raise AgentAdapterError('OpenCode v1 服务不提供模型清单；请使用 OpenCode 2 或更新版本')
        obj = self._call('/api/model', timeout=15)
        items = obj if isinstance(obj, list) else (obj.get('data') if isinstance(obj, dict) else [])
        models = []
        for item in items or []:
            if not isinstance(item, dict) or not isinstance(item.get('id'), str):
                continue
            provider = str(item.get('providerID') or '')
            variants = [str(v['id']) for v in (item.get('variants') or [])
                        if isinstance(v, dict) and v.get('id')]
            models.append({'id': item['id'], 'provider': provider,
                           'name': str(item.get('name') or item['id']),
                           'variants': variants, 'enabled': item.get('enabled') is not False,
                           'context': (item.get('limit') or {}).get('context')})
        return models

    def run(self, instruction: str, *, workspace: str | Path, session_id: str = '', timeout: float = 600) -> dict:
        if not instruction.strip() or len(instruction) > 50000:
            raise AgentAdapterError('Invalid instruction')
        if session_id and not re.fullmatch(r'[A-Za-z0-9_-]{1,120}', session_id):
            raise AgentAdapterError('Invalid OpenCode session id')
        self.info()
        if self.api == 2:
            return self._run_v2(instruction, workspace, session_id, timeout)
        return self._run_v1(instruction, workspace, session_id, timeout)

    def _run_v1(self, instruction, workspace, session_id, timeout):
        # CRITICAL: OpenCode HTTP server is bound to its own project, not the
        # TaskManager workspace. Fail closed rather than executing for another
        # user/project in a healthy but unrelated server.
        if Path(self.server_workspace()).resolve() != _workspace(workspace):
            raise AgentAdapterError('OpenCode server belongs to a different workspace')
        if not session_id:
            sess = self._call('/session', {'title': 'Open QQ Dot agent task'}, timeout=10)
            if not isinstance(sess, dict) or not isinstance(sess.get('id'), str):
                raise AgentAdapterError('OpenCode session creation failed')
            session_id = sess['id']
        path = '/session/' + quote(session_id, safe='') + '/message'
        result = self._call(path, {'parts': [{'type': 'text', 'text': instruction}]}, timeout=timeout)
        if not isinstance(result, dict) or not isinstance(result.get('parts'), list):
            raise AgentAdapterError('OpenCode returned an unexpected message')
        text = '\n'.join(part['text'] for part in result['parts'] if isinstance(part, dict) and
                         part.get('type') == 'text' and isinstance(part.get('text'), str))
        if not text.strip():
            raise AgentAdapterError('OpenCode did not return a completed text response')
        return {'output': text, 'session_id': session_id, 'backend': 'opencode',
                'verified': False, 'transport': 'http', 'tokens_used': 0}

    def _run_v2(self, instruction, workspace, session_id, timeout):
        """v2: a session carries its own directory, so the task runs in the authorized workspace even when
        the desktop app is looking at another folder. The prompt answers immediately with the queued user
        message, so the result is read back from the session until it reports idle."""
        target = str(_workspace(workspace))
        if not session_id:
            payload = {'title': 'Open QQ Dot agent task', 'location': {'directory': target}}
            if self.model:
                payload['model'] = {'providerID': self.model[0], 'id': self.model[1]}
                if self.variant:
                    payload['model']['variant'] = self.variant
            created = self._call('/api/session', payload, timeout=20)
            data = created.get('data') if isinstance(created, dict) else None
            if not isinstance(data, dict) or not isinstance(data.get('id'), str):
                raise AgentAdapterError('OpenCode session creation failed')
            session_id = data['id']
        sid = quote(session_id, safe='')
        self._call(f'/api/session/{sid}/prompt', {'text': instruction}, timeout=min(timeout, 120))
        deadline = time.monotonic() + timeout
        started = time.monotonic()
        while time.monotonic() < deadline:
            # 2026-10-26 user: a 你好 waited ~5.7 s, most of it the model; the fixed 1.5 s poll then added up to
            # another 1.5 s of pure waiting. Look often at first, back off once the answer is clearly slow.
            elapsed = time.monotonic() - started
            time.sleep(0.25 if elapsed < 4 else min(1.0, self.POLL_SECONDS))
            listing = self._call(f'/api/session/{sid}/message?limit=100&order=asc', timeout=15)
            items = listing.get('data') if isinstance(listing, dict) else None
            if not isinstance(items, list):
                continue
            idle = next((item for item in reversed(items)
                         if isinstance(item, dict) and item.get('type') == 'idle'), None)
            if idle is None:
                continue
            if idle.get('outcome') != 'succeeded' or idle.get('error'):
                raise AgentAdapterError('OpenCode 模型调用失败：' + _opencode_error(idle.get('error')))
            text = '\n'.join(_message_text(item) for item in items
                             if isinstance(item, dict) and item.get('type') == 'assistant').strip()
            if not text:
                raise AgentAdapterError('OpenCode did not return a completed text response')
            return {'output': text, 'session_id': session_id, 'backend': 'opencode',
                    'verified': False, 'transport': 'http', 'tokens_used': 0}
        raise AgentAdapterError('OpenCode 在限定时间内没有给出结果')


class StdioJsonRpc:
    """Minimal *client* transport for stdio ACP and MCP, with fail-closed reverse RPC.

    Persistent for the lifetime of this object. Never executes arbitrary reverse-RPC
    filesystem/terminal/approval requests; such operations require a separate
    authenticated human approval flow and sandbox outside this transport.
    """
    def __init__(self, command: list[str], workspace: str | Path, *, timeout: float = 30):
        if not isinstance(command, (tuple, list)) or not command or len(command) > 16 or any(
                not isinstance(a, str) or not a or '\0' in a or '\n' in a for a in command):
            raise AgentAdapterError('Invalid stdio command')
        self.command = [_validate_program(command[0]), *command[1:]]
        self.workspace = _workspace(workspace)
        self.timeout = timeout
        self.proc = None
        self.queue: queue.Queue = queue.Queue(maxsize=1000)
        self.events: list[dict] = []
        self.serial = 0
        self._pending = {}

    def __enter__(self):
        self.proc = subprocess.Popen(self.command, cwd=str(self.workspace), stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     text=True, encoding='utf-8', errors='replace', bufsize=1)
        try:
            from task_runtime import register_process
            register_process(self.proc)
        except Exception:
            self.proc.kill()
            self.proc.wait()
            raise
        def reader():
            try:
                for line in self.proc.stdout:
                    if len(line) > 2_000_000:
                        continue
                    try:
                        item = json.loads(line)
                        if isinstance(item, dict):
                            self.queue.put(item, timeout=1)
                    except (json.JSONDecodeError, queue.Full):
                        continue
            finally:
                try:
                    self.queue.put({'_eof': True}, timeout=1)
                except queue.Full:
                    pass
        threading.Thread(target=reader, daemon=True).start()
        return self

    def __exit__(self, *_):
        if self.proc:
            if self.proc.poll() is None:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=2)
            for handle in (self.proc.stdin, self.proc.stdout):
                if handle:
                    handle.close()
            from task_runtime import current_execution
            execution = current_execution.get()
            if execution:
                execution.manager.unregister_process(execution.task_id, self.proc.pid)

    def _send(self, message: dict):
        if not self.proc or self.proc.poll() is not None or not self.proc.stdin:
            raise AgentAdapterError('Agent stdio subprocess unavailable')
        self.proc.stdin.write(json.dumps(message, ensure_ascii=False) + '\n')
        self.proc.stdin.flush()

    def request(self, method: str, params: dict | None = None, *, timeout: float | None = None) -> object:
        self.serial += 1
        rid = self.serial
        self._send({'jsonrpc': '2.0', 'id': rid, 'method': method, 'params': params or {}})
        limit = time.monotonic() + (timeout or self.timeout)
        while time.monotonic() < limit:
            from task_runtime import current_execution
            execution = current_execution.get()
            if execution:
                execution.check()
            if rid in self._pending:
                packet = self._pending.pop(rid)
            else:
                try:
                    packet = self.queue.get(timeout=min(0.25, max(0.001, limit - time.monotonic())))
                except queue.Empty:
                    continue
            if packet.get('_eof'):
                raise AgentAdapterError(f'{method}: subprocess closed unexpectedly')
            if packet.get('id') is not None and packet.get('method'):
                # Never auto-approve reverse permissions or grant host file access.
                self._send({'jsonrpc': '2.0', 'id': packet['id'],
                            'error': {'code': -32601, 'message': 'Host permission not granted'}})
                continue
            if packet.get('id') == rid:
                if 'error' in packet:
                    # Avoid echoing arbitrary remote error details / credentials.
                    raise AgentAdapterError(f'{method} rejected by agent')
                return packet.get('result')
            if packet.get('id') is not None:
                self._pending[packet['id']] = packet
            elif len(self.events) < 200:
                self.events.append(packet)
        raise AgentAdapterError(f'{method}: response timeout')


def run_acp(command: list[str], instruction: str, workspace: str | Path, *,
            timeout: float = 600, protocol_version: int = 1, session_id: str = '') -> dict:
    if not 1 <= timeout <= 3600 or protocol_version not in (1, 2):
        raise AgentAdapterError('Invalid ACP options')
    if not instruction.strip() or len(instruction) > 50000:
        raise AgentAdapterError('Invalid instruction')
    with StdioJsonRpc(command, workspace, timeout=20) as rpc:
        initialization = ({'protocolVersion': 2, 'capabilities': {},
                           'info': {'name': 'Open QQ Dot', 'title': 'Open QQ Dot', 'version': '1'}}
                          if protocol_version == 2 else
                          {'protocolVersion': 1, 'clientCapabilities': {}})
        init = rpc.request('initialize', initialization)
        if not isinstance(init, dict):
            raise AgentAdapterError('ACP initialize returned no capabilities')
        if session_id:
            # Prefer lightweight resume. Fail closed if the agent doesn't support it.
            sess = rpc.request('session/resume', {'sessionId': session_id, 'cwd': str(_workspace(workspace)),
                                                  'mcpServers': []})
            sid = session_id
        else:
            sess = rpc.request('session/new', {'cwd': str(_workspace(workspace)), 'mcpServers': []})
            if not isinstance(sess, dict) or not isinstance(sess.get('sessionId'), str):
                raise AgentAdapterError('ACP session/new did not provide sessionId')
            sid = sess['sessionId']
        response = rpc.request('session/prompt', {'sessionId': sid,
                                                'prompt': [{'type': 'text', 'text': instruction}]}, timeout=timeout)
        if not isinstance(response, dict) or 'stopReason' not in response:
            raise AgentAdapterError('ACP prompt did not complete normally')
        if response['stopReason'] not in ('end_turn', 'endTurn', 'completed'):
            raise AgentAdapterError('ACP prompt stopped without normal completion')
        chunks = []
        for event in rpc.events:
            params = event.get('params') or {}
            if event.get('method') != 'session/update' or params.get('sessionId') != sid:
                continue
            update = params.get('update') or {}
            if update.get('sessionUpdate') == 'agent_message_chunk':
                content = update.get('content') or {}
                if content.get('type') == 'text' and isinstance(content.get('text'), str):
                    chunks.append(content['text'])
        output = ''.join(chunks).strip()
        if not output:
            # Some transports only signal completion, no final text; don't fabricate one.
            raise AgentAdapterError('ACP finished but did not stream an agent text response')
        return {'output': output, 'session_id': sid, 'backend': 'acp',
                'transport': 'acp', 'verified': False, 'tokens_used': 0}


def mcp_list_tools(command: list[str], workspace: str | Path, *, timeout: float = 15) -> list[dict]:
    with StdioJsonRpc(command, workspace, timeout=timeout) as rpc:
        rpc.request('initialize', {'protocolVersion': '2025-03-26', 'capabilities': {},
                                   'clientInfo': {'name': 'Open QQ Dot', 'version': '1.0'}})
        rpc._send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        tools, cursors, cursor = [], set(), None
        deadline = time.monotonic() + timeout
        for _ in range(100):
            if time.monotonic() >= deadline:
                raise AgentAdapterError('MCP 工具目录读取超时')
            result = rpc.request('tools/list', {'cursor': cursor}) if cursor else rpc.request('tools/list')
            if not isinstance(result, dict) or not isinstance(result.get('tools'), list):
                raise AgentAdapterError('MCP server returned no tools list')
            tools.extend(result['tools'])
            if len(tools) > 10000:
                raise AgentAdapterError('MCP 工具目录超过数量限制')
            cursor = result.get('nextCursor')
            if cursor is None:
                return tools
            if not isinstance(cursor, str) or not cursor or cursor in cursors:
                raise AgentAdapterError('MCP 工具目录分页游标无效或重复')
            cursors.add(cursor)
        raise AgentAdapterError('MCP 工具目录超过分页限制')



def mcp_call_tool(command: list[str], workspace: str | Path, name: str, arguments: dict, *,
                  timeout: float = 30) -> dict:
    if not isinstance(name, str) or not name or not isinstance(arguments, dict):
        raise AgentAdapterError('Invalid MCP tool invocation')
    with StdioJsonRpc(command, workspace, timeout=timeout) as rpc:
        rpc.request('initialize', {'protocolVersion': '2025-03-26', 'capabilities': {},
                                   'clientInfo': {'name': 'Open QQ Dot', 'version': '1.0'}})
        rpc._send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        result = rpc.request('tools/call', {'name': name, 'arguments': arguments})
        if not isinstance(result, dict) or result.get('isError'):
            raise AgentAdapterError('MCP server reported tool failure')
        return result


def run_agent(backend: str, instruction: str, workspace: str | Path, *,
              timeout: float = 600, allow_write: bool = False, config: dict | None = None) -> dict:
    """Dispatch only explicitly named/trusted backends; returns unverified output."""
    if backend not in BACKEND_NAMES or backend == 'mcp':
        raise AgentAdapterError('Invalid standalone agent backend')
    config = config or {}
    command = config.get('command')
    if command is not None:
        validate_command(command)
    # This config must come from trusted host settings, NOT user request/checkpoint.
    if backend == 'zcode':
        from agent_backends.zcode_backend import run
        return run(instruction, workspace, timeout=timeout, allow_write=allow_write, config=config)
    if backend in ('cursor', 'qwen_code'):
        return run_headless(backend, instruction, workspace, timeout=timeout, allow_write=allow_write,
                            **({'command': command} if command else {}))
    if backend == 'opencode':
        from agent_backends.transport_opencode import LocalOpenCode as _LocalOpenCode
        password = os.environ.get('OPENCODE_SERVER_PASSWORD', '')
        return _LocalOpenCode(config.get('url') or '', password=password,
                              model=config.get('model') or '',
                              variant=config.get('effort') or config.get('variant') or '').run(
            instruction, workspace=workspace, timeout=timeout)
    if backend == 'kimi_code':
        argv = command or ['kimi', 'acp']
    else:
        # Generic ACP requires trusted static administrator configuration.
        argv = config.get('command')
        if not isinstance(argv, list):
            raise AgentAdapterError('Generic ACP requires a trusted configured command')
    # A shared profile session_id is not owner-scoped. Always allocate a new
    # task-local session until durable user-bound session storage is available.
    from agent_backends.transport_acp import run_acp as _run_acp
    result = _run_acp(argv, instruction, workspace, timeout=timeout,
                      protocol_version=int(config.get('protocol_version', 1)))
    result['backend'] = backend
    return result


def validate_command(command):
    if (not isinstance(command, list) or not command or len(command) > 64 or
            any(not isinstance(arg, str) or len(arg) > 4096 or any(c in arg for c in '\r\n\0') for arg in command)
            or not command[0].strip()):
        raise ValueError('启动命令须为程序路径与参数组成的非空字符串数组')


def require_native_permissions(profile):
    from task_runtime import current_execution
    execution = current_execution.get()
    permissions = execution.effective_permissions() if execution else (profile or {}).get('computer_tools', {})
    if not (permissions.get('enabled') and permissions.get('commands') and
            permissions.get('full_computer_access') and not permissions.get('read_only') and
            permissions.get('mode') != 'read_only'):
        raise PermissionError('请先在项目权限中授权命令执行及完整电脑访问；外部工具没有经过验证的工作区沙箱')
    if execution:
        execution.check()


def generate_text(prompt, directory, profile, *, image_path=None, text_only=False, output_schema=None,
                  record_input=None):
    """Use the same trusted adapter path from chat, console and orchestration."""
    if image_path is not None or text_only or output_schema is not None:
        raise AgentAdapterError('此接入暂不支持图片、强制纯文本隔离或结构化输出协议，请选择其他智能体')
    require_native_permissions(profile)
    from task_runtime import current_execution
    import workspace_tools
    backend = profile['model_api']['provider']
    config = (profile.get('agent_adapters') or {}).get(backend) or {}
    execution = current_execution.get()
    workspace = (execution.workspace() if execution else
                 (profile.get('computer_tools') or {}).get('project_path') or workspace_tools.workspace(directory))
    Path(workspace).mkdir(parents=True, exist_ok=True)
    if record_input:
        record_input(prompt, {'provider': backend, 'input_scope': 'initial_user_message.text',
                              'tool_followups_recorded': False})
    result = run_agent(backend, prompt, workspace, config=config, allow_write=True)
    if execution:
        execution.check()
    return result['output'], result.get('session_id') or None


def probe_adapter(backend, config, workspace):
    """Explicit desktop connectivity check; does not submit an agent task."""
    if backend == 'opencode':
        client = LocalOpenCode(config.get('url') or '',
                               password=os.environ.get('OPENCODE_SERVER_PASSWORD', ''),
                               model=config.get('model') or '',
                               variant=config.get('variant') or '')
        info = client.info()
        where = client.server_workspace()
        version = info.get('version')
        return ((f'服务连接正常（OpenCode {version}，{client.base_url()}）；'
                 f'服务工作目录：{where}') if version else
                ('服务连接正常（v1 服务）；服务工作目录：' + where))
    command = config.get('command')
    if command:
        validate_command(command)
    elif backend == 'zcode':
        from agent_backends.zcode_backend import cli_command
        command = cli_command(config)
    else:
        spec = BUILTINS[backend]
        command = [spec.executable, *spec.args] if spec.executable else None
    if not command:
        raise ValueError('请先设置程序路径和启动参数')
    if backend in ('cursor', 'qwen_code', 'zcode'):
        try:
            found = _validate_program(command[0])
        except AgentAdapterError:
            if backend != 'cursor' or config.get('command'):
                raise
            found = _validate_program('cursor-agent')
        return '已检测到程序：' + found + '；登录状态需通过实际任务确认'
    if backend == 'mcp':
        tools = mcp_list_tools(command, workspace)
        return '工具服务握手成功，可用工具：' + ('、'.join(str(t.get('name')) for t in tools) or '无')
    with StdioJsonRpc(command, workspace, timeout=15) as rpc:
        version = int(config.get('protocol_version', 1))
        initialization = ({'protocolVersion': 2, 'capabilities': {},
                           'info': {'name': 'Open QQ Dot', 'title': 'Open QQ Dot', 'version': '1'}}
                          if version == 2 else {'protocolVersion': 1, 'clientCapabilities': {}})
        rpc.request('initialize', initialization)
    return '智能体协议握手成功；尚未提交执行任务'


def mcp_server_configs(directory):
    """Every enabled MCP tool server of this friend, keyed by a CLI-safe name.

    2026-10-26 user: 工具服务不可能只接一个。旧配置（单个 command）仍然照常读，
    新的 `servers` 列表可以同时接多个；每个都要单独校验命令，不能因为一个坏了就全部不接。
    """
    try:
        profile = json.loads((Path(directory) / 'friend.json').read_text('utf-8'))
    except (OSError, ValueError):
        return {}
    config = (profile.get('agent_adapters') or {}).get('mcp') or {}
    raw = config.get('servers')
    entries = []
    if isinstance(raw, list) and raw:
        for item in raw:
            if isinstance(item, dict):
                entries.append(item)
    elif config.get('command'):
        # 兼容旧配置：单个服务器。
        entries.append({'name': 'external_tools', 'command': config.get('command'),
                        'enabled': config.get('enabled', True)})
    if not any(item.get('enabled', True) for item in entries):
        return {}
    require_native_permissions(profile)
    servers = {}
    for index, item in enumerate(entries):
        if not item.get('enabled', True):
            continue
        command = item.get('command')
        try:
            validate_command(command)
        except (TypeError, ValueError, AgentAdapterError):
            continue  # 一个坏的不影响其它的
        name = re.sub(r'[^0-9A-Za-z_-]', '_', str(item.get('name') or f'tool_{index + 1}'))[:32] or f'tool_{index + 1}'
        if name in ('qq_topic_library', 'qq_phone', 'agent_mailbox'):
            name = 'external_' + name
        stem = name
        suffix = 2
        while name in servers:
            name = f'{stem}_{suffix}'
            suffix += 1
        servers[name] = {'command': _validate_program(command[0]), 'args': list(command[1:])}
    return servers


def mcp_server_config(directory):
    """Backwards-compatible single server (the first enabled one)."""
    servers = mcp_server_configs(directory)
    return next(iter(servers.values()), None)
