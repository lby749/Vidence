# Open QQ Dot · BETA 测试版

中文介绍、安装说明、功能状态与验证边界已统一维护在 [README.md](README.md)，避免两个入口内容不同步。
